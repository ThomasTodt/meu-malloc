#include "meuAlocador.h" 

int main() {
  void *a, *b, *c;
  iniciaAlocador();
  a=alocaMem(10);
  // b=alocaMem(2);
  c=alocaMem(3);
  // liberaMem(b);
  liberaMem(c);
  // c=alocaMem(4);
  imprimeMapa();
  // b=alocaMem(200);
  // imprimeMapa();
  // liberaMem(a);
  // imprimeMapa();
  // a=alocaMem(50);
  // imprimeMapa();

  finalizaAlocador();

}
